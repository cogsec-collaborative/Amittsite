--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE amittsite;
--
-- Name: amittsite; Type: DATABASE; Schema: -; Owner: sara
--

CREATE DATABASE amittsite WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE amittsite OWNER TO sara;

\connect amittsite

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: counter; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.counter (
    amitt_id text,
    tactic_id text,
    metatechnique_id text,
    name text,
    summary text,
    id bigint
);


ALTER TABLE public.counter OWNER TO sara;

--
-- Name: counter_tactic; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.counter_tactic (
    counter_id text,
    tactic_id text,
    main_tactic text,
    summary text,
    id bigint
);


ALTER TABLE public.counter_tactic OWNER TO sara;

--
-- Name: counter_technique; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.counter_technique (
    counter_id text,
    technique_id text,
    summary text,
    id bigint
);


ALTER TABLE public.counter_technique OWNER TO sara;

--
-- Name: detection; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.detection (
    amitt_id text,
    tactic_id text,
    name text,
    summary text,
    id bigint
);


ALTER TABLE public.detection OWNER TO sara;

--
-- Name: detection_tactic; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.detection_tactic (
    detection_id text,
    tactic_id text,
    main_tactic text,
    summary text,
    id bigint
);


ALTER TABLE public.detection_tactic OWNER TO sara;

--
-- Name: detection_technique; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.detection_technique (
    detection_id text,
    technique_id text,
    summary text,
    id bigint
);


ALTER TABLE public.detection_technique OWNER TO sara;

--
-- Name: framework; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.framework (
    amitt_id text,
    name text,
    summary text,
    id bigint
);


ALTER TABLE public.framework OWNER TO sara;

--
-- Name: metatechnique; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.metatechnique (
    amitt_id text,
    name text,
    summary text,
    id bigint
);


ALTER TABLE public.metatechnique OWNER TO sara;

--
-- Name: phase; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.phase (
    amitt_id text,
    name text,
    rank text,
    summary text,
    id bigint
);


ALTER TABLE public.phase OWNER TO sara;

--
-- Name: tactic; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.tactic (
    amitt_id text,
    phase_id text,
    name text,
    rank text,
    summary text,
    id bigint
);


ALTER TABLE public.tactic OWNER TO sara;

--
-- Name: task; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.task (
    amitt_id text,
    tactic_id text,
    framework_id text,
    name text,
    summary text,
    id bigint
);


ALTER TABLE public.task OWNER TO sara;

--
-- Name: technique; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.technique (
    amitt_id text,
    tactic_id text,
    name text,
    summary text,
    id bigint
);


ALTER TABLE public.technique OWNER TO sara;

--
-- Name: test; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.test (
    index bigint,
    detection_id text,
    tactic_id text,
    main_tactic text,
    summary text,
    id bigint
);


ALTER TABLE public.test OWNER TO sara;

--
-- Name: test2; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.test2 (
    index bigint,
    detection_id text,
    tactic_id text,
    main_tactic text,
    summary text,
    id bigint
);


ALTER TABLE public.test2 OWNER TO sara;

--
-- Name: user; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public."user" (
    username text,
    password text,
    id bigint
);


ALTER TABLE public."user" OWNER TO sara;

--
-- Name: users; Type: TABLE; Schema: public; Owner: sara
--

CREATE TABLE public.users (
    username text,
    password text,
    id bigint
);


ALTER TABLE public.users OWNER TO sara;

--
-- Data for Name: counter; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.counter (amitt_id, tactic_id, metatechnique_id, name, summary, id) FROM stdin;
\.
COPY public.counter (amitt_id, tactic_id, metatechnique_id, name, summary, id) FROM '$$PATH$$/3324.dat';

--
-- Data for Name: counter_tactic; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.counter_tactic (counter_id, tactic_id, main_tactic, summary, id) FROM stdin;
\.
COPY public.counter_tactic (counter_id, tactic_id, main_tactic, summary, id) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: counter_technique; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.counter_technique (counter_id, technique_id, summary, id) FROM stdin;
\.
COPY public.counter_technique (counter_id, technique_id, summary, id) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: detection; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.detection (amitt_id, tactic_id, name, summary, id) FROM stdin;
\.
COPY public.detection (amitt_id, tactic_id, name, summary, id) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: detection_tactic; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.detection_tactic (detection_id, tactic_id, main_tactic, summary, id) FROM stdin;
\.
COPY public.detection_tactic (detection_id, tactic_id, main_tactic, summary, id) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: detection_technique; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.detection_technique (detection_id, technique_id, summary, id) FROM stdin;
\.
COPY public.detection_technique (detection_id, technique_id, summary, id) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: framework; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.framework (amitt_id, name, summary, id) FROM stdin;
\.
COPY public.framework (amitt_id, name, summary, id) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: metatechnique; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.metatechnique (amitt_id, name, summary, id) FROM stdin;
\.
COPY public.metatechnique (amitt_id, name, summary, id) FROM '$$PATH$$/3327.dat';

--
-- Data for Name: phase; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.phase (amitt_id, name, rank, summary, id) FROM stdin;
\.
COPY public.phase (amitt_id, name, rank, summary, id) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: tactic; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.tactic (amitt_id, phase_id, name, rank, summary, id) FROM stdin;
\.
COPY public.tactic (amitt_id, phase_id, name, rank, summary, id) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.task (amitt_id, tactic_id, framework_id, name, summary, id) FROM stdin;
\.
COPY public.task (amitt_id, tactic_id, framework_id, name, summary, id) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: technique; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.technique (amitt_id, tactic_id, name, summary, id) FROM stdin;
\.
COPY public.technique (amitt_id, tactic_id, name, summary, id) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.test (index, detection_id, tactic_id, main_tactic, summary, id) FROM stdin;
\.
COPY public.test (index, detection_id, tactic_id, main_tactic, summary, id) FROM '$$PATH$$/3321.dat';

--
-- Data for Name: test2; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.test2 (index, detection_id, tactic_id, main_tactic, summary, id) FROM stdin;
\.
COPY public.test2 (index, detection_id, tactic_id, main_tactic, summary, id) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public."user" (username, password, id) FROM stdin;
\.
COPY public."user" (username, password, id) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sara
--

COPY public.users (username, password, id) FROM stdin;
\.
COPY public.users (username, password, id) FROM '$$PATH$$/3336.dat';

--
-- Name: ix_test2_index; Type: INDEX; Schema: public; Owner: sara
--

CREATE INDEX ix_test2_index ON public.test2 USING btree (index);


--
-- Name: ix_test_index; Type: INDEX; Schema: public; Owner: sara
--

CREATE INDEX ix_test_index ON public.test USING btree (index);


--
-- PostgreSQL database dump complete
--

